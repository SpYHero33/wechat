// miniprogram/pages/choose/choose.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    seat:[
      [1 ,1 ,0, 1 ,1],
      [1, 1, 0, 1, 1],
      [1, 1, 0, 2, 1],
      [1, 1, 0, 2, 1],
      [1, 1, 0, 1, 2],
      [1, 1, 0, 1, 2],
      [1, 1, 0, 1, 1],
      [1, 2, 0, 1, 1],
      [1, 1, 0, 1, 1],
      [1, 1, 1, 1, 1]
    ],
    items: [
      { value: 0, checked: true },
      { value: 1, checked: false },
      { value: 2, checked: false },
      { value: 3, checked: false },
      { value: 4, checked: false },
      { value: 5, checked: false },
      { value: 6, checked: false },
      { value: 7, checked: false },
      { value: 8, checked: false },
      { value: 9, checked: true },
      { value: 10, checked: false },
      { value: 11, checked: false },
      { value: 12, checked: true },
      { value: 13, checked: false },
      { value: 14, checked: false },
      { value: 15, checked: true },
      { value: 16, checked: true },
      { value: 17, checked: false },
      { value: 18, checked: false },
      { value: 19, checked: true },
      { value: 20, checked: false },
      { value: 21, checked: true },
      { value: 22, checked: false },
      { value: 23, checked: false },
      { value: 24, checked: false },
      { value: 25, checked: true },
      { value: 26, checked: false },
      { value: 27, checked: false },
      { value: 28, checked: true },
      { value: 29, checked: true },
      { value: 30, checked: true },
      { value: 31, checked: false },
      { value: 32, checked: false },
    ]
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  },
  checkboxchange: function (e) {
    console.log(e)
    var items = this.data.items;
    var checkArr = e.detail.value;
    for (var i = 0; i < items.length; i++) {
      if (checkArr.indexOf(i + "") != -1) {
        items[i].checked = true;
      } else {
        items[i].checked = false;
      }
    }
    this.setData({
      items: items
    })
  },
})