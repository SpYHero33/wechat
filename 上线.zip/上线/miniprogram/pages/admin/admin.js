// pages/admin/admin.js
const db = wx.cloud.database()
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    number: null,
    routine: null,
    carnumber: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.time()

  },
  panel: function (e) {
    if (e.currentTarget.dataset.index != this.data.showIndex) {
      this.setData({
        showIndex: e.currentTarget.dataset.index
      })
    } else {
      this.setData({
        showIndex: 0
      })
    }
  },
  tap: function () {
    wx.navigateTo({
      url: '../statistics/statistics'
    })
  },
  time: function () {
    var date = new Date()
    var date01 = new Date(date.getTime() + 24 * 60 * 60 * 1000)
    var alltime = date01.getFullYear() + '.' + (date01.getMonth() + 1) + '.' + date01.getDate()
    this.setData({ time: alltime })
    var dtime = date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds()
    this.setData({
      detail: dtime
    })
  },
  incar: function (e) {
    this.setData({ carnumber: e.detail.value })
    console.log(e.detail.value)
  },
  innum: function (e) {
    this.setData({ number: e.detail.value })
    console.log(e.detail.value)
  },
  inroutine: function (e) {
    this.setData({ routine: e.detail.value })
    console.log(e.detail.value)
  },
  inidnumber: function (e) {
    this.setData({ idnumber: e.detail.value })
    console.log(e.detail.value)
  },
  incarnumber: function (e) {
    this.setData({ carnumber: e.detail.value })
    console.log(e.detail.value)
  },


  testifnull: function () {
    var that = this
    if (this.data.number != null && this.data.routine != null && this.data.carnumber != null) {
      wx.showModal({
        title: '提示',
        content: '确定增加车次么',
        success: function (res) {
          if (res.confirm) {
            wx.showToast({
              title: '正在增加车次',
              icon: 'loading',
              duration: 10000
            })
            that.addcar()
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
    else {
      wx.showModal({
        title: '提示',
        content: '您有遗漏的信息没有填',
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
  },
  
  addcar: function () {

    wx.cloud.callFunction({
      name: 'database_addcar',
      data: {
        carnumber: this.data.carnumber,
        total: this.data.number,
        time: this.data.time,
        routine: this.data.routine,
        detail: this.data.detail
      },
      success: res => {
        console.log(res.result.errMsg == 'collection.add:ok')
        if (res.result.errMsg == 'collection.add:ok') {
          wx.hideToast()
          wx.showToast({
            title: '添加成功',
            icon: 'success',
            duration: 2000
          })
          setTimeout(function () {
            wx.reLaunch({
              url: '../bus/bus'
            })
          }, 2000)
        }
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
      }
    }),
      console.log(this.data.number)
    var num = parseInt(this.data.number)
    for (var i = 1; i < num + 1; i++) {
      console.log(i)
      wx.cloud.callFunction({
        name: 'database_addticket',
        data: {
          carnumber: this.data.carnumber,
          location: i,
          time: this.data.time,
          routine: this.data.routine,
        },
        success: res => {
          //console.log(res)
        },
        fail: err => {
          console.error('[云函数] [login] 调用失败', err)
        }
      })
    }
  },
  hbuy: function () {
    var that = this
    var num = 0
    wx.showModal({
      title: '提示',
      content: '确定要订票么',
      success: function (res) {
        if (res.confirm) {
          db.collection('Car').where({
            time: that.data.time,
            carnumber: that.data.carnumber
          }).get({
            success(res) {
              console.log(res)
              for (var i = 1; i < (res.data[0].total + 1); i++) {
                console.log(i + 1)
                db.collection('ticket').where({
                  carnumber: that.data.carnumber,
                  location: i,
                  time: that.data.time
                })
                  .get({
                    success(res) {
                      if (res.data[0].bought == 0) {
                        num = res.data[0].location
                        that.setData({
                          datafortime: res.data[0].location
                        })
                      }
                    },
                    fail: console.error
                  })
              }

              that.setData({
                car: res.data[0]
              })
            },
            fail: console.error
          })
          setTimeout(function () {
            var iid = that.data.carnumber
            var location = that.data.datafortime
            var ttime = that.data.time
            console.log(iid, location, ttime)
            wx.cloud.callFunction({
              name: 'database_buyticket',
              data: {
                carnumber: iid,
                location: location,
                time: ttime,
                openid: app.globalData.openid
              },
              success: res => {
                if (res.result.stats.updated == 0) {
                  console.log('res')
                }
                if (res.result.stats.updated == 1) {
                  wx.showToast({
                    title: '购票成功',
                    icon: 'success',
                    duration: 1000
                  })
                  setTimeout(function () {
                    wx.reLaunch({
                      url: '../bus/bus'
                    })
                  }, 1000)
                  console.log('OKKKKK')
                }
              },
              fail: err => {
                console.error('[云函数] [login] 调用失败', err)
              }
            })
          }, 2000)
        } else {
          console.log('用户点击取消')
        }
      }
    })

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})