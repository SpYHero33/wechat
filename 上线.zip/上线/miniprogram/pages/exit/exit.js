// pages/exit/exit.js
const app = getApp()
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    car: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var date = new Date()
    var date01 = new Date(date.getTime() + 24 * 60 * 60 * 1000)
    const hour = date.getHours()
    const minute = date.getMinutes()
    const second = date.getSeconds()

    var dtime = date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds()
    this.setData({
      detail: dtime
    })

    if (hour < 7) {
      var alltime = date.getFullYear() + '.' + (date.getMonth() + 1) + '.' + date.getDate()
    }
    else {
      var alltime = date01.getFullYear() + '.' + (date01.getMonth() + 1) + '.' + date01.getDate()
    }
    this.setData({ time: alltime })
    var that = this
    db.collection('ticket').where({
      openid: app.globalData.openid,
      time: this.data.time
    }).get({
      success(res) {
        that.setData({
          car: res.data
        })
      }
    })
  },
  refund: function (e) {
    console.log(e)
    wx.showToast({
      title: '退票中',
      icon: 'loading',
      duration: 10000
    })
    wx.cloud.callFunction({
      name: 'database_refund',
      data: {
        time: this.data.time,
        openid: app.globalData.openid
      },
      success: res => {
        console.log(res)
        if (res.result.stats.updated == 0) {
          console.log('res')
        }
        if (res.result.stats.updated != 0) {
          wx.hideToast()
          wx.showToast({
            title: '退票成功',
            icon: 'success',
            duration: 1000
          })
          setTimeout(function () {
            wx.reLaunch({
              url: '../bus/bus'
            })
          }, 1000)

          console.log('OKKKKK')
        }
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})