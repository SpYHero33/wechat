(function() {
    const a = a => (a = a.toString(), a[1] ? a : "0" + a);
    var b = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", c = [ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 ];
    module.exports = {
        isTrueAlpha: a => {
            var b = /^[A-Za-z]*$/;
            return b.test(a) && 1 < a.length;
        },
        shuffle: a => {
            var b = [];
            for (let c = 0; c < a; c++) b.push(c);
            for (var c = a; c--; ) {
                var d = parseInt(Math.random() * a), e = b[c];
                b[c] = b[d], b[d] = e;
            }
            return b;
        },
        contains: (a, b) => {
            for (var c = a.length; c--; ) if (a[c] === b) return !0;
            return !1;
        },
        isAlpha: a => {
            var b = /^[A-Za-z]*$/;
            return b.test(a) && 1 < a.length || -1 != escape(a).indexOf("%u");
        },
        formatTime: b => {
            const c = b.getFullYear(), d = b.getMonth() + 1, e = b.getDate(), f = b.getHours(), g = b.getMinutes(), h = b.getSeconds();
            return [ c, d, e ].map(a).join("/") + " " + [ f, g, h ].map(a).join(":");
        },
        formatDate: b => {
            const c = b.getFullYear(), d = b.getMonth() + 1, e = b.getDate();
            return [ c, d, e ].map(a).join("-");
        },
        getCookie: (a, b) => {
            for (var c = b || [], d = a.split(","), e = 0; e < d.length; e++) if (!(0 >= d[e].indexOf("="))) {
                var f = d[e].split(";");
                if (0 < f.length) {
                    var g = f[0].split("=");
                    1 < g.length && (c[g[0]] = g[1]);
                }
            }
            return c;
        },
        setCookie: a => {
            var b = "";
            for (var c in a) "" != b && (b += "; "), b = b + c + "=" + a[c];
            return b;
        },
        base64decode: a => {
            var b, d, e, f, g, h, i, j = String.fromCharCode;
            for (h = a.length, g = 0, i = ""; g < h; ) {
                do {
                    b = c[255 & a.charCodeAt(g++)];
                } while (g < h && -1 == b);
                if (-1 == b) break;
                do {
                    d = c[255 & a.charCodeAt(g++)];
                } while (g < h && -1 == d);
                if (-1 == d) break;
                i += j(b << 2 | (48 & d) >> 4);
                do {
                    if (e = 255 & a.charCodeAt(g++), 61 == e) return i;
                    e = c[e];
                } while (g < h && -1 == e);
                if (-1 == e) break;
                i += j((15 & d) << 4 | (60 & e) >> 2);
                do {
                    if (f = 255 & a.charCodeAt(g++), 61 == f) return i;
                    f = c[f];
                } while (g < h && -1 == f);
                if (-1 == f) break;
                i += j((3 & e) << 6 | f);
            }
            return i;
        },
        base64encode: a => {
            var c, d, e, f, g, h;
            for (e = a.length, d = 0, c = ""; d < e; ) {
                if (f = 255 & a.charCodeAt(d++), d == e) {
                    c += b.charAt(f >> 2), c += b.charAt((3 & f) << 4), c += "==";
                    break;
                }
                if (g = a.charCodeAt(d++), d == e) {
                    c += b.charAt(f >> 2), c += b.charAt((3 & f) << 4 | (240 & g) >> 4), c += b.charAt((15 & g) << 2), 
                    c += "=";
                    break;
                }
                h = a.charCodeAt(d++), c += b.charAt(f >> 2), c += b.charAt((3 & f) << 4 | (240 & g) >> 4), 
                c += b.charAt((15 & g) << 2 | (192 & h) >> 6), c += b.charAt(63 & h);
            }
            return c;
        }
    };
})();