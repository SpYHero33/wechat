const cloud = require('wx-server-sdk')
cloud.init()
const db = cloud.database()
exports.main = async (event, context) => {
  try {
    return await db.collection('ticket').where({
      carnumber: event.carnumber,
      location:parseInt(event.location),
      time:event.time,
      bought: parseInt('0')
    }).update({
      // data 传入需要局部更新的数据
      data: {
        bought: 1,
        detail:event.detail,
        openid:event.openid
      }
    })
    
  } catch (e) {
    console.error(e)
  }
}