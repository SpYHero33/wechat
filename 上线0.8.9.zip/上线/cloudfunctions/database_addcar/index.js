const cloud = require('wx-server-sdk')
cloud.init()
const db = cloud.database()
exports.main = async (event, context) => {
  try {
    return await db.collection('Car').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        carnumber: event.carnumber,
        total: parseInt(event.total),
        left: parseInt(event.total),
        routine: event.routine,
        time: event.time
      }
    })
  } catch (e) {
    console.error(e)
  }
}