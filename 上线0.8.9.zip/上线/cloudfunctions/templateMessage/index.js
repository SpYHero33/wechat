// 通过云调用，推送模板消息
const cloud = require('wx-server-sdk')
cloud.init()
exports.main = async (event, context) => {

  var busnumber = event.busnumber;
  var content = event.content;
  var openid = event.openid;
  var formid = event.formid;
  var time = event.time;
  var location = event.location;
  var routine = event.routine;

  try {
    const result = await cloud.openapi.templateMessage.send({
      touser: cloud.getWXContext().OPENID, // 通过 getWXContext 获取 OPENID
      page: 'pages/ticket/ticket',
      data: {
        keyword1: {
          value: time // 发车时间
        },
        keyword2: {
          value: routine // 班次路线
        },
        keyword3: {
          value: busnumber // 车辆信息
        },
        keyword4: {
          value: time // 出发时间
        },
        keyword5: {
          value: location // 座位信息
        },
        keyword6: {
          value: content // 备注
        }
      },
      templateId: '5_58ckdWYiZ35pqQRiG9wFRPHrpzFTfdgJmMsBXbfJk', // 模板消息ID
      formId: formid, // 推送码
      emphasisKeyword: ''
    })
    // result 结构
    // { errCode: 0, errMsg: 'openapi.templateMessage.send:ok' }
    return result
  } catch (err) {
    // 错误处理
    // err.errCode !== 0
    throw err
  }
}