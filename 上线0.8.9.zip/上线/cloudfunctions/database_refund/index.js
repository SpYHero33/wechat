const cloud = require('wx-server-sdk')
cloud.init()
const db = cloud.database()
exports.main = async (event, context) => {
  try {
    return await db.collection('ticket').where({
      openid:event.openid,
      time:event.time
    }).update({
      // data 传入需要局部更新的数据
      data: {
        bought: parseInt('0'),
        openid:0
      }
    })

  } catch (e) {
    console.error(e)
  }
}