const app = getApp()
const db = wx.cloud.database()

Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    admin: 0
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  tap5: function () {
    wx.navigateTo({
      url: '../history/history'
    })
  },
  tap4: function () {
    wx.navigateTo({
      url: '../exit/exit'
    })
  },
  tap3: function () {
    wx.navigateTo({
      url: '../text/text'
    })
  },
  tap2: function () {
    wx.navigateTo({
      url: '../about/about'
    })
  },
  tap1: function () {
    wx.navigateTo({
      url: '../admin/admin'
    })
  },
  onLoad: function () {
    var that = this
    db.collection('User').where({
      openid: app.globalData.openid
    }).get({
      success(res) {
        console.log(res.data[0].admin)
        if (res.data[0].admin == 1) {
          that.setData({
            admin: 1
          })
        }
      }
    })
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function (e) {
    var that = this
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }


})
