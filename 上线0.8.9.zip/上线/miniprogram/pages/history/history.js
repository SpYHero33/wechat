// pages/history/history.js
const app = getApp()
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */

  data: {
    time: '2019.3.27',
    car: false,
    hid: true

  },

  datachange: function (e) {
    var y1 = e.detail.value.charAt(2)
    var y2 = e.detail.value.charAt(3)
    var m1 = e.detail.value.charAt(5)
    var m2 = e.detail.value.charAt(6)
    var d1 = e.detail.value.charAt(8)
    var d2 = e.detail.value.charAt(9)
    if (m1 == 0) {
      if (d1 == 0) {
        this.setData({
          time: '20' + y1 + y2 + '.' + m2 + '.' + d2
        })
      }
      if (d1 != 0) {
        this.setData({
          time: '20' + y1 + y2 + '.' + m2 + '.' + d1 + d2
        })
      }
    }
    if (m1 != 0) {
      if (d1 == 0) {
        this.setData({
          time: '20' + y1 + y2 + '.' + m1 + m2 + '.' + d2
        })
      }
      hid
      if (d1 != 0) {
        this.setData({
          time: '20' + y1 + y2 + '.' + m1 + m2 + '.' + d1 + d2
        })
      }
    }
    //上面为对时间格式的更改，保存到this.data.time里，下面为对car的更改
    var that = this
    db.collection('ticket').where({
      openid: app.globalData.openid,
      time: this.data.time
    }).get({
      success(res) {
        that.setData({
          car: res.data
        })

      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */


  onLoad: function (options) {
    wx.showToast({
      title: '正在查询',
      icon: 'loading',
      duration: 10000
    })
    var that = this
    console.log('whatttt')

    wx.cloud.callFunction({
      name: 'database_gethistory',
      data: {
        openid: app.globalData.openid
      },
      success: res => {
        wx.hideToast()
        console.log('yes it can run')
        console.log(res.result.data)
        that.setData({
          car: res.result.data
        })
      },
      fail: res => {
        wx.hideToast()
        wx.showModal({
          title: '提示',
          content: '您还没有预订过票',
          success: function (res) {
            if (res.confirm) {
              wx.reLaunch({
                url: '../bus/bus'
              })
            } else {
              wx.reLaunch({
                url: '../bus/bus'
              })
            }
          }
        })
      }
    })
  },
  q1: function () {
    this.data.hid = false;
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})