const app = getApp()
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    car: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var date = new Date()
    var date01 = new Date(date.getTime() + 24 * 60 * 60 * 1000)
    const hour = date.getHours()
    const minute = date.getMinutes()
    const second = date.getSeconds()
    if (hour < 8) {
      var alltime = date.getFullYear() + '.' + (date.getMonth() + 1) + '.' + date.getDate()
    }
    else {
      var alltime = date01.getFullYear() + '.' + (date01.getMonth() + 1) + '.' + date01.getDate()
    }
    this.setData({ time: alltime })
    console.log(this.data.time)
    var that = this
    db.collection('ticket').where({
      openid: app.globalData.openid,
      time: this.data.time
    }).get({
      success(res) {
        console.log(res.data)
        if (res.data.length == 0) {
          console.log('还没有预订车票')
          wx.showModal({
            title: '提示',
            content: '您还没预订当天的票',
            success: function (res) {
              if (res.confirm) {
                console.log('用户点击确定')
                wx.reLaunch({
                  url: '../bus/bus'
                })
              } else {
                wx.reLaunch({
                  url: '../bus/bus'
                })
                console.log('用户点击取消')
              }
            }
          })
        }
        else {
          that.setData({
            car: res.data[0]
          })
        }
      }
    })
    db.collection('User').where({
      openid: app.globalData.openid
    }).get({
      success(res) {
        console.log(res.data)
        that.setData({
          user: res.data[0]
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})