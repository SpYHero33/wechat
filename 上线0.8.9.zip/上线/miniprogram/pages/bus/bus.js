// pages/bus/bus.js
const app = getApp()
const db = wx.cloud.database()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    openid: null,
    routine: null,
    carr: false,
    car: false,
    regdata: null,
    time: null,
    datafortime: 'nodata',
    carnumber: 'Σ(っ °Д °;)っ',
    registered: false,
    _id:null
  },

  /**
   * 生命周期函数--监听页面加载
   */

  onLoad: function (options) {
    wx.showToast({
      title: '正在查询',
      icon: 'loading',
      duration: 10000
    })
    this.onGetOpenid()
    this.time()
    this.getcar()
  },

  register: function () {
    wx.navigateTo({
      url: '../login/login'
    })
  },

  getcar: function () {
    var that = this
    var time = this.data.time
    var caar = null
    wx.cloud.callFunction({
      name: 'database_getallcars',
      data: {
        time: time
      },
      success: res => {
        console.log(res.result.data)
        caar = res.result.data
        wx.cloud.callFunction({
          name: 'database_getalltickets',
          data: {
            time: time
          },
          success: res => {
            console.log(res.result.data)
            that.setData({
              ticket: res.result.data
            })
            var carr = caar
            var ticket = res.result.data
            for (var i = 0; i < carr.length; i++) {
              var a = 0
              for (var j = 0; j < ticket.length; j++) {
                if ((ticket[j].carnumber == carr[i].carnumber) && (ticket[j].bought == 0)) {
                  a = a + 1
                }
                carr[i].left = a
                wx.hideToast()
                app.globalData.car = carr
              }
              that.setData({
                car: carr
              })
              console.log(a)
            }

          },
          fail: err => {
            wx.hideToast()
            console.log('没有车次')
          }
        })
      },
      fail: err => {
        console.log(err)
      }
    })
  },

  onGetOpenid: function () {
    //在小程序一开始启动就会检测是否已经注册
    var that = this
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        app.globalData.openid = res.result.openid
        db.collection('User').where({
          openid: res.result.openid
        }).get({
          success(res) {
            if (res.data.length) {
              that.setData({
                registered: true
              })
            }
          }
        })
      }
    })
  },

  time: function () {
    var date = new Date()
    var date01 = new Date(date.getTime() + 24 * 60 * 60 * 1000)
    const hour = date.getHours()
    const minute = date.getMinutes()
    const second = date.getSeconds()

    var dtime = date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds()
    this.setData({
      detail: dtime
    })

    if (hour < 7) {
      var alltime = date.getFullYear() + '.' + (date.getMonth() + 1) + '.' + date.getDate()
    }
    else {
      var alltime = date01.getFullYear() + '.' + (date01.getMonth() + 1) + '.' + date01.getDate()
    }
    this.setData({ time: alltime })
  },

  buy: function (e) {
    var that = this
    wx.showToast({
      title: '正在查询',
      icon: 'loading',
      duration: 10000
    })
    if (!this.data.registered) {
      wx.reLaunch({
        url: '../login/login'
      })
      return 0
    }
    var openid = app.globalData.openid
    var ticket = this.data.ticket
    var buytick = true
    for (var i = 0; i < ticket.length; i++) {
      if (ticket[i].openid == openid) {
        console.log(ticket[i])
        var buytick = false
        wx.hideToast()
        wx.showModal({
          title: '提示',
          content: '您已经订过当天的票了',
          success: function (res) {
            if (res.confirm) {
              console.log('用户点击确定')
            } else {
              console.log('用户点击取消')
            }
          }
        })
        break
      }
    }

    if (buytick) {
      wx.hideToast()
      wx.showModal({
        title: '提示',
        content: '您确定要预订车票么',
        success: function (res) {
          if (res.confirm) {
            that.buyticket(e)
            console.log('用户点击确定')
            wx.showToast({
              title: '预订车票中',
              icon: 'loading',
              duration: 10000
            })
          } else {
            console.log('用户点击取消')
          }
        }
      })
    }
  },

  ifRegistered: function (e) {
    //test要改成user
    var that = this
    db.collection('User').where({
      openid: app.globalData.openid
    }).get({
      success(res) {
        console.log(res, app.globalData.openid)
        if (res.data.length) {
          that.setData({
            registered: true
          })
        }
      }
    })
  },

  buyticket: function (e) {
    var that = this
    var ticket = this.data.ticket
    var location = null
    var _id = null
    var j=null
    for (var i = 0; i < ticket.length; i++) {
      if (ticket[i].bought == 0 && ticket[i].carnumber == e.currentTarget.id) {
        location = ticket[i].location
        _id = ticket[i]._id
        j=i
        break
      }
    }

    db.collection('ticket').where({
      _id: _id
    }).get({
      success: function (res) {
        console.log(res.data[0])
        if (res.data[0].bought == parseInt('0')) {
          var iid = e.currentTarget.id
          var ttime = that.data.time
          console.log(iid, location, ttime)
          console.log(that.data.detail)
          wx.cloud.callFunction({
            name: 'database_buyticket',
            data: {
              carnumber: iid,
              location: location,
              time: ttime,
              openid: app.globalData.openid,
              detail: that.data.detail,
            },
            success: res => {

              db.collection('ticket').where({
                time:that.data.time,
                openid:app.globalData.openid
              })
                .get({
                  success: res => {
                  if (res.data.length == 1){
                    wx.hideToast()
                    wx.showToast({
                      title: '订票成功',
                      icon: 'success',
                      duration: 1000
                    })
                    setTimeout(function () {
                      wx.reLaunch({
                        url: '../ticket/ticket'
                      })
                    }, 1000)
                  }
                  if (res.data.length == 0){
                    wx.hideToast()
                    wx.showToast({
                      title: '抢票失败',
                      icon: 'none',
                      duration: 1000
                    })
                    setTimeout(function () {
                      wx.reLaunch({
                        url: '../bus/bus'
                      })
                    }, 1000)
                  }
                  console.log('sadad')},
                  fail: console.error
                })
            },
            fail: err => {
              console.error('[云函数] [login] 调用失败', err)
            }
          })
        }

        if (res.data[0].bought == parseInt('1')) {
          that.data.ticket[j].bought = parseInt('1')
          that.buyticket(e)
          return 0
        }
      }
    })
    //e.currentTarget.dataset.total
  },

  db_buyticket: function (e) {
    console.log(e.currentTarget.id)
    wx.cloud.callFunction({
      name: 'database_buyticket',
      data: {
        carnumber: e.currentTarget.id,
        location: this.data.datafortime,
        time: this.data.time,
        detail: this.data.detail
      },
      success: res => {
        console.log(res)
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
      }
    })
  },

  onReady: function () {
  },



  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  inquire: function () {

  }
})